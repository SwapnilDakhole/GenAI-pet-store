from fastapi import FastAPI
from app.routers import file_upload_routes, semantic_search_router  
# import schedule
import time as tm
from datetime import time, timedelta, datetime
# from app.routers.file_upload_routes import process_file


app = FastAPI(
    title="LangChain Document Processing API",
    description="An API to upload documents, search for similar documents, and answer questions.",
    version="1.0.0",
)

app.include_router(file_upload_routes.router, prefix="/documents", tags=["Document Upload"])

app.include_router(semantic_search_router.router, prefix="/queries", tags=["Query Processing"])

# def job():
#     print("Schedular activated")

# schedule.every(30).seconds.do(process_file)

# while True:
#     schedule.run_pending()
#     tm.sleep(1)

# Run the app using `uvicorn app.main:app --reload`
