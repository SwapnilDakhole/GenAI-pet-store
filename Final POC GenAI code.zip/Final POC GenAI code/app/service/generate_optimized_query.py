# app/service/generate_optimized_query.py
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain.chat_models import ChatOpenAI
from app.config.pinecone_config import OPENAI_API_KEY

def generate_optimized_query(user_query: str) -> str:
    try:
        template = """
        Refine the following user query to make it suitable for semantic search.
        Original Query: {query}
        Optimized Query:
        """
        prompt = PromptTemplate(template=template, input_variables=["query"])
        llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0.7, openai_api_key=OPENAI_API_KEY)
        chain = LLMChain(prompt=prompt, llm=llm)
        return chain.run(query=user_query)
    except Exception as e:
        print(f"Error in generate_optimized_query: {str(e)}")
        return user_query
