import requests
import json
import re

def call_api(endpoint: str, base_url: str = "https://petstore.swagger.io/v2") -> dict:
    """
    Makes a GET request to the specified API endpoint and returns the JSON response as a dictionary.
    
    Parameters:
        endpoint (str): The API endpoint (e.g., "/api/v1/users/1").
        base_url (str): The base URL of the API (default is "https://example.com").
    
    Returns:
        dict: The JSON response object from the API.
    
    Raises:
        ValueError: If the API response status code is not 200 or if the response is not valid JSON.
    """
    try:
        # Construct the full URL
        if not endpoint.startswith("/"):
            endpoint = f"/{endpoint}"  # Ensure the endpoint starts with a slash
        full_url = f"{base_url}{endpoint}"
        
        # Make the GET request
        response = requests.get(full_url)
        
        # Check for HTTP errors
        response.raise_for_status()  # Raises HTTPError if the response code is 4xx or 5xx
        
        # Attempt to parse the response as JSON
        response_data = response.json()
        
        return response_data
    except requests.exceptions.RequestException as req_error:
        print(f"Request error: {req_error}")
        raise ValueError(f"Failed to fetch data from API: {full_url}") from req_error
    except ValueError as json_error:
        print(f"JSON parsing error: {json_error}")
        raise ValueError(f"Invalid JSON response from API: {full_url}") from json_error


def clean_api_url(response: str) -> str:
    """
    Clean the extracted API URL by removing extra punctuation and unwanted characters.
    """
    cleaned_url = re.sub(r'[^\w:/\.\-_\?\&=]', '', response.strip())
    if re.match(r'^https?:\/\/', cleaned_url):
        raise ValueError("Invalid API URL extracted.")
    
    return cleaned_url
