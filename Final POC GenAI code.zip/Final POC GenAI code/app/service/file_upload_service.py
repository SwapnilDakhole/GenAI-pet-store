import json
import os
from langchain_community.document_loaders import DirectoryLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain.vectorstores import Pinecone as LangchainPinecone
from langchain_community.llms import OpenAI
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain.chains.question_answering import load_qa_chain
from langchain_community.chat_models import ChatOpenAI
from fastapi import UploadFile
from typing import List
from app.config.pinecone_config import INDEX_NAME, MODEL_NAME
from langchain.schema import Document


embeddings = OpenAIEmbeddings(model="text-embedding-ada-002")
llm = OpenAI(model_name=MODEL_NAME)

def save_uploaded_files(files: List[UploadFile], upload_dir: str = "/tmp/uploaded_files") -> str:
    # Ensure cross-platform compatibility for directory path
    if not os.path.exists(upload_dir):
        os.makedirs(upload_dir, exist_ok=True)
        print(f"Created directory: {upload_dir}")
    
    # Remove existing files in the directory before saving new ones
    for file in os.listdir(upload_dir):
        file_path = os.path.join(upload_dir, file)
        if os.path.isfile(file_path):
            os.remove(file_path)
            print(f"Removed existing file: {file_path}")
    
    # Save new uploaded files
    for file in files:
        file_path = os.path.join(upload_dir, file.filename)
        with open(file_path, "wb") as f:
            file_content = file.file.read()
            f.write(file_content)
            print(f"Saved file: {file_path}")

    return upload_dir

# def load_and_split_docs(directory: str, chunk_size=300, chunk_overlap=20):
#     """Load documents from a directory and split them into chunks."""
#     loader = DirectoryLoader(directory)
#     documents = loader.load()
#     text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
#     return text_splitter.split_documents(documents)

def load_and_split_docs(directory: str, chunk_size=300, chunk_overlap=20):
    """Load documents from a directory and split them into chunks."""
    all_chunks = []
    for file_name in os.listdir(directory):
        file_path = os.path.join(directory, file_name)
        if os.path.isfile(file_path) and file_name.endswith('.json'):
            try:
                with open(file_path, 'r') as file:
                    data = json.load(file)
                text = json.dumps(data, indent=2)
                text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
                chunks = text_splitter.split_text(text)
                documents = [Document(page_content=chunk, metadata={"source": file_name}) for chunk in chunks]
                all_chunks.extend(documents)
            except json.JSONDecodeError as e:
                print(f"Error parsing JSON file {file_name}: {e}")
                continue
    return all_chunks

def pinecone_index(docs):
    """Initialize or update the Pinecone index with document embeddings using LangChain."""
    pinecone_index = LangchainPinecone.from_documents(docs, embeddings, index_name=INDEX_NAME)
    return pinecone_index

def process_uploaded_files(files: list[UploadFile], chunk_size=300, chunk_overlap=20):
    upload_dir = save_uploaded_files(files)
    chunks = load_and_split_docs(upload_dir, chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    pinecone_index(chunks)
    return {"message": "Files processed and indexed successfully"}
