from langchain.vectorstores import Pinecone as LangchainPinecone
from app.config.pinecone_config import INDEX_NAME
# from app.utils.optimize_query_agent import optimized_query_agent
from langchain_openai import OpenAIEmbeddings
from app.config.pinecone_config import OPENAI_API_KEY

embeddings = OpenAIEmbeddings(
    model="text-embedding-ada-002", openai_api_key=OPENAI_API_KEY
)

def fetch_contextual_data(user_query: str, k: int = 2, score: bool = False) -> str:
    """
    Fetch contextual data using Pinecone based on an optimized query.

    Args:
        user_query (str): The input query from the user.
        k (int, optional): Number of top results to retrieve. Defaults to 2.
        score (bool, optional): Whether to include scores in the results. Defaults to False.

    Returns:
        str: A concatenated string of the retrieved contextual data or an error message.
    """
    try:
        # Connect to the existing Pinecone index
        pinecone_index = LangchainPinecone.from_existing_index(
            index_name=INDEX_NAME,
            embedding=embeddings
        )

        # Perform semantic search
        if score:
            results = pinecone_index.similarity_search_with_score(user_query, k=k)
            contextual_data = "\n".join(
                f"Score: {score}, Content: {doc.page_content}" for doc, score in results
            )
        else:
            results = pinecone_index.similarity_search(user_query, k=k)
            contextual_data = "\n".join(doc.page_content for doc in results)

        print(f"Contextual Data Retrieved: {contextual_data}")
        return contextual_data or "No relevant contextual data found."

    except Exception as e:
        print(f"Error in fetch_contextual_data: {str(e)}")
        return f"Error: {str(e)}"


# Simplified wrapper for fetching contextual data
# def fetch_contextual_data_with_single_input(user_query: str) -> str:
#     """
#     Wrapper function for `fetch_contextual_data` with default parameters.

#     Args:
#         user_query (str): The input query from the user.

#     Returns:
#         str: Contextual data retrieved for the query.
#     """
#     return fetch_contextual_data(user_query, k=3, score=False)
