from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.service.llm_response_service import get_llm_response  # Import the get_llm_response function
from app.service.api_request_service import call_api
from typing import Dict, Union

router = APIRouter()


class UserQuery(BaseModel):
    query: str


class LLMResponse(BaseModel):
    response: Dict[str, Union[str, dict]]


@router.post("/ask/", response_model=LLMResponse)
async def ask_question(user_query: UserQuery):
    """
    Endpoint to process a user query, optimize it, retrieve contextual data, 
    and return the LLM response.
    """
    try:
        # Get the LLM response
        llm_response = get_llm_response(user_query.query)

        # Ensure the response is valid
        if not llm_response:
            raise HTTPException(status_code=404, detail="No response generated.")

        # Convert fields to strings if they exist
        for field in ["Sample request body", "Response body"]:
            if field in llm_response:
                llm_response[field] = str(llm_response[field])

        # Log the API response for debugging
        print(f"API Response: {llm_response}")

        return {"response": llm_response}

    except Exception as e:
        # Raise an HTTPException for internal server errors
        raise HTTPException(status_code=500, detail=f"Internal Server Error: {str(e)}")
