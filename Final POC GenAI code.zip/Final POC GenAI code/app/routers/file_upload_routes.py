from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi import FastAPI
from pathlib import Path
from typing import List
from app.utils.agents import file_upload_agent
from app.service.file_upload_service import process_uploaded_files
import logging

router = APIRouter()
app = FastAPI()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

file_path = Path(r"E:\Python\Project_file_upload\project_demo.txt")


@router.post("/upload/")
async def upload_files(files: List[UploadFile] = File(...)):
    """Endpoint to upload files, process them, and initialize Pinecone."""
    try:
        # Call the agent
        # response = file_upload_agent.run(input="Process the uploaded files.")
        response = process_uploaded_files(files)
        return {"message": "Processing complete", "details": response}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# def process_file():
#     """Load the file from the specified path and run the agent."""
#     try:
#         if file_path.exists():
#             # Read file content
#             with open(file_path, "r", encoding="utf-8") as f:
#                 file_content = f.read()

#             # Process file content with the agent
#             response = file_upload_agent.run(input=f"Process this file content: {file_content}")
#             logger.info({"message": "Processing complete", "details": response})
#         else:
#             logger.warning({"error": "File not found at the specified path."})
#     except Exception as e:
#         logger.error({"error": str(e)})