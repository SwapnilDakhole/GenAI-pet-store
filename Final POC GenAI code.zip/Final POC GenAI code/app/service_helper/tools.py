from langchain.tools import StructuredTool

from app.service.file_upload_service import save_uploaded_files, load_and_split_docs, pinecone_index

# from app.service.semantic_search_service import fetch_contextual_data_with_single_input

# Save files tool
save_files_tool = StructuredTool.from_function(
    func=save_uploaded_files,
    name="Save Files",
    description="Save uploaded files to a temporary directory. Input: List of uploaded files. Output: Directory path."
)

# Split documents tool
split_docs_tool = StructuredTool.from_function(
    func=load_and_split_docs,
    name="Split Documents",
    description="Load documents from a directory and split them into chunks. Input: Directory path. Output: Number of "
                "documents split."
)

# Pinecone tool
pinecone_tool = StructuredTool.from_function(
    func=pinecone_index,
    name="Initialize Pinecone and upload the documents to pinecone",
    description="Initialize or update Pinecone index with document embeddings. Input: Number of documents. Output: Status message. and uploads the documents to the Pinecone database provided"
)

# List of tools
file_upload_tools = [save_files_tool, split_docs_tool, pinecone_tool]


# # Define the new tool with a single input
# fetch_context_tool_single_input = StructuredTool.from_function(
#     func=fetch_contextual_data_with_single_input,
#     name="Fetch Contextual Data",
#     description="Perform semantic search on Pinecone and retrieve relevant documents. Input: Query string. Output: Contextual data.",
# )