# app>service_helper>optimize_query_tool
from langchain.tools import StructuredTool
from app.service.semantic_search_service import fetch_contextual_data


def fetch_contextual_data_with_single_input(user_query: str) -> str:
    return fetch_contextual_data(user_query, k=3, score=False)


def get_semantic_search_tool() -> StructuredTool:
    return StructuredTool.from_function(
        func=fetch_contextual_data_with_single_input,
        name="Semantic Search",
        description=(
            "Fetch contextual data using semantic search based on the user query. "
            "Input: Optimized query string. Output: Contextual data for further processing."
        ),
    )


# Initialize the tool
semantic_search_tool = get_semantic_search_tool()
