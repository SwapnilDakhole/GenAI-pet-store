# app>service_helper>optimize_query_tool
from langchain.tools import StructuredTool
from app.service.generate_optimized_query import generate_optimized_query


def get_optimize_query_tool():
    return StructuredTool.from_function(
        func=generate_optimized_query,
        name="Optimize Query",
        description="Refine a user query for semantic search. Input: Query string. Output: Optimized query.",
    )


optimize_query_tool = get_optimize_query_tool()
