# app>utils>query_agent.py
import os

from dotenv import load_dotenv
from langchain.agents import initialize_agent, AgentType
from langchain.chat_models import ChatOpenAI

from app.service_helper.optimize_query_tool import optimize_query_tool
from app.service_helper.semantic_search_tool import semantic_search_tool

load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
chat = ChatOpenAI(model_name="gpt-3.5-turbo", temperature=0.2, openai_api_key=OPENAI_API_KEY)

tools = [
    optimize_query_tool,  # First tool to optimize the query
    semantic_search_tool,  # Second tool to fetch contextual data
]

query_agent = initialize_agent(
    tools=tools,
    llm=chat,
    agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
    verbose=True,
)