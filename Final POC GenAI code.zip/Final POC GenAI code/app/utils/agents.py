import os
from langchain.chat_models import ChatOpenAI
import openai
from langchain.agents import initialize_agent, AgentType
from dotenv import load_dotenv
from app.service_helper.tools import file_upload_tools

load_dotenv()

# OpenAI and Pinecone configuration
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

chat = ChatOpenAI(model_name="gpt-3.5-turbo", temperature=0.2, openai_api_key=OPENAI_API_KEY)

file_upload_agent = initialize_agent(
    tools=file_upload_tools,
    llm=chat,
    agent=AgentType.STRUCTURED_CHAT_ZERO_SHOT_REACT_DESCRIPTION,
    verbose=True
)

# semantic_search_agent = initialize_agent(
#     tools=[fetch_context_tool_single_input],  # Use the fetch context tool for the semantic search agent
#     llm=chat,
#     agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,  # React to the user input by selecting the search tool
#     verbose=False,
# )

# # Function to process the semantic search
# def process_semantic_search(user_query: str) -> str:
#     """
#     Process the query using the semantic search agent.
#     This will perform a semantic search and return the contextual data.
#     """
#     return semantic_search_agent.run(user_query)

