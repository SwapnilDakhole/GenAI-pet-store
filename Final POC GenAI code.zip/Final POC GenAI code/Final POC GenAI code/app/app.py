import requests
import streamlit as st

st.set_page_config(page_title="Pet Store JSON Viewer", layout="wide")

st.title("Document Search Swagger API")

question = st.text_input("Enter your question:", "", key="question_input")

API_URL = "http://127.0.0.1:8000/queries/ask/"
BASE_URL = "https://petstore.swagger.io/v2"

if st.button("Submit"):
    if question.strip():
        with st.spinner("Fetching response..."):
            try:
                response = requests.post(API_URL, json={"query": question}, timeout=10)

                if response.status_code == 200:
                    try:
                        json_response = response.json()

                        # Check for different possible keys for API endpoint URL
                        response_data = json_response.get("response", {})
                        api_url = response_data.get("API_endpoint_URL") or response_data.get("endpointURL")

                        if api_url:
                            if not api_url.startswith("http"):
                                api_url = f"{BASE_URL}{api_url}"
                            response_data["API_endpoint_URL"] = api_url  # Normalize the field

                        st.json(json_response)

                    except ValueError:
                        st.error("Invalid JSON response from API")
                else:
                    st.error(f"Error {response.status_code}: {response.text}")

            except requests.exceptions.RequestException as e:
                st.error(f"Request failed: {str(e)}")

    else:
        st.warning("Please enter a question before submitting.")
