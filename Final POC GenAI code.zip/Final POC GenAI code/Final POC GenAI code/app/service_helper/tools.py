from langchain.tools import StructuredTool
from app.service.file_upload_service import save_uploaded_files, load_and_split_docs, faiss_index

# Save files tool
save_files_tool = StructuredTool.from_function(
    func=save_uploaded_files,
    name="Save Files",
    description="Save uploaded files to a temporary directory. Input: List of uploaded files. Output: Directory path."
)

# Split documents tool
split_docs_tool = StructuredTool.from_function(
    func=load_and_split_docs,
    name="Split Documents",
    description="Load documents from a directory and split them into chunks. Input: Directory path. Output: List of split document chunks."
)

# FAISS indexing tool (Replacing Pinecone)
faiss_tool = StructuredTool.from_function(
    func=faiss_index,
    name="FAISS Indexing",
    description="Index document embeddings using FAISS. Input: List of document chunks. Output: Status message."
)

# List of tools (replace Pinecone tool with FAISS tool)
file_upload_tools = [save_files_tool, split_docs_tool, faiss_tool]
