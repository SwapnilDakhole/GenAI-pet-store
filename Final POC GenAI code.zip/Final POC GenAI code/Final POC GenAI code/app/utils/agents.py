import os
from langchain.chat_models import ChatOpenAI
import openai
from langchain.agents import initialize_agent, AgentType
from dotenv import load_dotenv
from app.service_helper.tools import file_upload_tools
from app.config.pinecone_config import OPENAI_API_KEY

load_dotenv()

chat = ChatOpenAI(model_name="gpt-3.5-turbo", temperature=0.2, openai_api_key=OPENAI_API_KEY)

# Initialize the FAISS-based file upload agent
file_upload_agent = initialize_agent(
    tools=file_upload_tools,
    llm=chat,
    agent=AgentType.STRUCTURED_CHAT_ZERO_SHOT_REACT_DESCRIPTION,
    verbose=True
)
