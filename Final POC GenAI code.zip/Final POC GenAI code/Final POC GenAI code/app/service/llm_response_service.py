# app > service > llm_response_service.py
import json

from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain_community.chat_models import ChatOpenAI
from app.utils.query_agent import query_agent
import os
from dotenv import load_dotenv

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")


def get_llm_response(user_query: str, k: int = 3, score: bool = False) -> dict:
    """
    Generate a response using ChatOpenAI based on contextual data.
    """
    try:
        # Fetch contextual data
        contextual_data = query_agent.run(user_query)

        # Define the prompts
        system_prompt = """
        You are a helpful assistant providing detailed API information. Your task is to extract:
        - API endpoint URL
        - HTTP method (GET, POST, etc.)
        - Brief summary of the API
        - Sample request and response body in JSON format
        - Status codes and their descriptions.
        Provide responses in JSON format without additional text.
        """
        user_prompt = f"""
        Contextual Documents:
        {contextual_data}

        Query:
        {user_query}
        """

        # Combine system and user prompts
        combined_prompt = system_prompt + user_prompt

        # Define LLMChain with a single variable 'context'
        prompt = PromptTemplate(template="{context}", input_variables=["context"])
        llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0.7, openai_api_key=OPENAI_API_KEY)
        llm_chain = LLMChain(prompt=prompt, llm=llm)

        # Run the chain with the combined prompt
        llm_response = llm_chain.run(context=combined_prompt)
        print(f"Raw LLM Response: {llm_response}")

        # Strip any extra formatting like code blocks
        llm_response = llm_response.strip()
        if llm_response.startswith("```json"):
            llm_response = llm_response[7:].strip()  # Remove leading ```json
        if llm_response.endswith("```"):
            llm_response = llm_response[:-3].strip()  # Remove trailing ```

        # Safely parse response into a dictionary
        try:
            parsed_response = json.loads(llm_response)
        except json.JSONDecodeError as e:
            print(f"Error parsing LLM response: {e}")
            parsed_response = {"error": "Failed to parse LLM response into valid JSON."}

        return parsed_response

    except Exception as e:
        print(f"Error in get_llm_response: {str(e)}")
        return {"error": f"Internal Server Error: {str(e)}"}
