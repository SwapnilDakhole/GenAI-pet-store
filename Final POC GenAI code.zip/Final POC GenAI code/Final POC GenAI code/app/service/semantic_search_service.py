import os
from dotenv import load_dotenv
from langchain.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings

load_dotenv()

# Define FAISS index path
FAISS_INDEX_PATH = "./faiss_index"

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

embeddings = OpenAIEmbeddings(
    model="text-embedding-ada-002", openai_api_key=OPENAI_API_KEY
)


def load_faiss_index():
    """Load an existing FAISS index from disk or handle missing index case."""
    try:
        if os.path.exists(FAISS_INDEX_PATH):
            return FAISS.load_local(FAISS_INDEX_PATH, embeddings, allow_dangerous_deserialization=True)
        else:
            print("FAISS index not found. Creating a new empty index.")
            return None
    except Exception as e:
        print(f"Error loading FAISS index: {str(e)}")
        return None


def fetch_contextual_data(user_query: str, k: int = 2, score: bool = False) -> str:
    """
    Fetch contextual data using FAISS based on an optimized query.

    Args:
        user_query (str): The input query from the user.
        k (int, optional): Number of top results to retrieve. Defaults to 2.
        score (bool, optional): Whether to include scores in the results. Defaults to False.

    Returns:
        str: A concatenated string of the retrieved contextual data or an error message.
    """
    try:
        # Load FAISS index
        faiss_index = load_faiss_index()
        if faiss_index is None:
            return "No FAISS index found. Please index documents first."

        # Perform semantic search
        if score:
            results = faiss_index.similarity_search_with_score(user_query, k=k)
            contextual_data = "\n".join(
                f"Score: {score}, Content: {doc.page_content}" for doc, score in results
            )
        else:
            results = faiss_index.similarity_search(user_query, k=k)
            contextual_data = "\n".join(doc.page_content for doc in results)

        print(f"Contextual Data Retrieved: {contextual_data}")
        return contextual_data or "No relevant contextual data found."

    except Exception as e:
        print(f"Error in fetch_contextual_data: {str(e)}")
        return f"Error: {str(e)}"
