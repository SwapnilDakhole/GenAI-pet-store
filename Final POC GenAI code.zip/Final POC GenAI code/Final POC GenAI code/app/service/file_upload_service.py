import json
import os
from typing import List

from fastapi import UploadFile
from langchain.schema import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores import FAISS
from langchain_community.llms import OpenAI
# Initialize OpenAI embeddings
from langchain_openai import OpenAIEmbeddings
import os
from dotenv import load_dotenv

load_dotenv()


OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

embeddings = OpenAIEmbeddings(model="text-embedding-ada-002", openai_api_key=OPENAI_API_KEY)

llm = OpenAI(model_name="text-davinci-003")

# FAISS index file path
FAISS_INDEX_PATH = "./faiss_index"


def save_uploaded_files(files: List[UploadFile], upload_dir: str = "/tmp/uploaded_files") -> str:
    """Save uploaded files to a temporary directory."""
    if not os.path.exists(upload_dir):
        os.makedirs(upload_dir, exist_ok=True)

    # Remove existing files in the directory
    for file in os.listdir(upload_dir):
        file_path = os.path.join(upload_dir, file)
        if os.path.isfile(file_path):
            os.remove(file_path)

    # Save new uploaded files
    for file in files:
        file_path = os.path.join(upload_dir, file.filename)
        with open(file_path, "wb") as f:
            f.write(file.file.read())

    return upload_dir


def load_and_split_docs(directory: str, chunk_size=300, chunk_overlap=20):
    """Load JSON documents from a directory and split them into chunks."""
    all_chunks = []
    for file_name in os.listdir(directory):
        file_path = os.path.join(directory, file_name)
        if os.path.isfile(file_path) and file_name.endswith(".json"):
            try:
                with open(file_path, "r") as file:
                    data = json.load(file)
                text = json.dumps(data, indent=2)
                text_splitter = RecursiveCharacterTextSplitter(
                    chunk_size=chunk_size, chunk_overlap=chunk_overlap
                )
                chunks = text_splitter.split_text(text)
                documents = [
                    Document(page_content=chunk, metadata={"source": file_name})
                    for chunk in chunks
                ]
                all_chunks.extend(documents)
            except json.JSONDecodeError as e:
                print(f"Error parsing JSON file {file_name}: {e}")
                continue
    return all_chunks


def faiss_index(docs):
    """Index document embeddings in FAISS."""
    # Create FAISS vector store
    vector_store = FAISS.from_documents(docs, embeddings)

    # Save FAISS index
    vector_store.save_local(FAISS_INDEX_PATH)
    return vector_store


def process_uploaded_files(files: List[UploadFile], chunk_size=300, chunk_overlap=20):
    """Process uploaded files: save, split, and index them in FAISS."""
    upload_dir = save_uploaded_files(files)
    chunks = load_and_split_docs(
        upload_dir, chunk_size=chunk_size, chunk_overlap=chunk_overlap
    )
    faiss_index(chunks)
    return {"message": "Files processed and indexed successfully"}
