import os
from dotenv import load_dotenv
import openai

load_dotenv()

# OpenAI and Pinecone configuration
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
INDEX_NAME = "project-index"
MODEL_NAME = "gpt-3.5-turbo"

# Set OpenAI API key
openai.api_key = OPENAI_API_KEY

# # Initialize Pinecone with API key and environment
# pc = Pinecone(api_key=PINECONE_API_KEY, environment=PINECONE_ENVIRONMENT)
#
# # Check if the index already exists; create it if it does not
# existing_indexes = [index.name for index in pc.list_indexes()]
# if INDEX_NAME not in existing_indexes:
#     pc.create_index(
#         name=INDEX_NAME,
#         dimension=1536,  # The dimension of the embeddings, adjust if different
#         metric='euclidean',  # Metric for similarity search, e.g., cosine, euclidean, etc.
#         spec=ServerlessSpec(
#             cloud='aws',
#             region=PINECONE_ENVIRONMENT
#         )
#     )
#
# # Initialize the index
# index = pc.Index(name=INDEX_NAME, host="https://project-index-9sjvphk.svc.aped-4627-b74a.pinecone.io")
